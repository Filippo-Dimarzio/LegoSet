
import controllers.LegoSetAPI;
import models.InstructionBooklet;
import models.LegoSet;
import utils.Utilities;
import java.util.ArrayList;
import java.util.Scanner;

public class Driver {


    private Scanner input = new Scanner(System.in);

    private LegoSetAPI legoSetAPI = new LegoSetAPI();
    private int indexToDelete;
    private int isValidIndexToUpdate;
    private int legoSetPiece;
    private String e;
    private int IndexToUpdate;
    private Object Scannerinput;
    private int indexToUpdate;
    private Object ScannerInput;


//TODO Define an object of the LegoSetAPI here. It should be declared private.



public static void main (String[] args) { new Driver(); }

//TODO Refer to the tutors instructions for building this class.  You are free to deviate in any way
//     from the Driver menu that is in the tutors instructions, once you have these included:
//       - CRUD on LegoSet
//       - CRUD on Instruction Booklets
//       - Search facility (for LegoSets and Booklets)
//       - Reports
//       - Persistence
// Note:  This is the ONLY class that can talk to the user i.e. have System.out.print and Scanner reads in it.


public Driver() {runMenu();}

  //----------------------------------------------------------------------------
    // Private methods for displaying the menu and processing the selected options
    //----------------------------------------------------------------------------

    private int mainMenu() {
    System.out.print("""
                |------------------------------------------------------------------
                |                            LEGO SET APP                          |
                |------------------------------------------------------------------
                |   1) Add a lego set                                            |
                |   2) List all lego set                                          |
                |   3) Update all lego set                                          |
                |   4) Delete all lego set                                           |----------------------------------------------------------------
                |   5) Set a stock status of a lego set                              |
                |   6) Find a specific Lego set (by code)                       |
                |   7) Search for all lego sets (by name)                                |
                |-------------------------------------------------------------------------------
                |Instruction booklet MENU--
                |   8)  Add a booklet to a lego set--------------------------------------
                |   9)  List all booklets                          |
                |   10) update a booklet on a leo set
                |   11) Delete a booklet from a lego set
                |   12) Search, for all booklets (by file name)
                ----------------------------------------------------------------------------
                | REPORT MENU
                |   13) print overall stock report
                |    14) print all lego sets by chose theme
                |    15) print all lego sets at or above a minimum age
                |    16)
                |    17)
                |    18)
                |    19)
                | ---------------------------------------------------------------------
                |     SETTING MENU
                |     20)
                |     21)
                |     0)
                |------------------------------------------------------------------
                ==>>
                """);
        int option = input.nextInt();
        return option;
        }

        private void runMenu() {
        int option = mainMenu();

        while (option != 0) {
        switch(option) {
        case 1-> addLegoSet();
        case 2-> viewLegoSetsMenu();
        case 3-> updateLegoSets();
        case 4-> deleteLegoSets();
        case 5-> setStockStatusForLegoSets();
        case 6-> findLegoSetsByCode();
        case 7-> SearchLegoSetByName();
        case 8-> addBookletToLegoSet();
        case 9-> printAllBooklets();
        case 10-> updateBookletInLegoSet();
        case 11-> deleteBookletFromLegoSet();
        case 12-> searchBookletsByFileName();
        case 13-> printStockReport();
        case 14-> printLegoSetsBySelectedTheme();
        case 15-> printLegoSetsByMinAge();
        case 16-> save();
        case 17-> load();

        default -> System.out.println("Invalid option entered: "+ option);
        }
        System.out.println("\nPress enter key to continue");
        input.nextLine();
        input.nextLine();
        option = mainMenu();
        }
        System.out.println("Exiting");
        System.exit ( 0);
        }

    private void save() {
    }

    private void printLegoSetsByMinAge() {

    }

    private void printStockReport() {

    }

    private void findLegoSetsByCode() {

    }

    private void load() {

    }

    private void printLegoSetsBySelectedTheme() {

    }

    private void deleteBookletFromLegoSet() {

    }

    private void searchBookletsByFileName() {

    }

    private void printAllBooklets() {

    }

    private void updateBookletInLegoSet() {

    }

    private void addBookletToLegoSet() {

    }

    private void SearchLegoSetByName() {

    }

    private void setStockStatusForLegoSets() {

    }

    private void deleteLegoSets() {

    }

    private void updateLegoSets() {

    }

    private void viewLegoSetsMenu() {

    }


//------------------------------------
// Private methods for CRUD on LegoSet
//------------------------------------

private void addLegoSet() {
        input.nextLine();
        System.out.print("type lego set name: ");
        String legoSetName = input.nextLine();
        System.out.print("type lego set code: ");
        int legoSetCode = input.nextInt();
        System.out.print("Enter the lego set Cost: ");
        double legoSetCost = input.nextDouble();
        System.out.print ("how many pieces are in the set: ");
        int LegoSetPiece = input.nextInt();
        System.out.print("type lego set theme: ");
        String theme = input.nextLine();
        System.out.print("type lego set mininum age: ");
        int age = input.nextInt();

        boolean isAdded = legoSetAPI.addLegoSet (new LegoSet(legoSetName, legoSetCode, legoSetCost, legoSetPiece, theme, age));
        if (isAdded){
        System.out.println("Product Added ");
        else{
        System.out.println("No Product Added ");
        }
        }

   private void viewLegoSetsMenu() {
        System.out.println("all lego sets are:");
        System.out.println(legoSetAPI.listAllLegoSets();
        }

      private void updateLegoSets{
        viewLegoSetsMenu();

        private void deleteBookletFromLegoSet(){
            viewLegoSetsMenu();
        if (LegoSetAPI.numberOfLegoSets() > 0) {
        int IndexToUpdate = ScannerInput.readNextInt( "Enter the index of the lego set to delete a booklet from :");
        input.nextLine();
        InstructionBooklet bookletToDelete = legoSetAPI.findLegoSet (indexToDelete).deleteInstructionBooklet(IndexToDelete);
        if (bookletToDelete != null){
        System.out.println("delete sucessful");
        }
        else{
        System.out.println("delete failed");}
        }
        }

        else{
        System.out.println("No lego sets to delete");
        }
}

//-----------------------------------------------------------------
//  Private methods for Search facility (for LegoSets and Booklets)
//-----------------------------------------------------------------






//-----------------------------
//  Private methods for Reports
// ----------------------------



     //---------------------------------
     //  Private methods for Persistence
     // --------------------------------

private void save() {
    try{
        legoSetAPI.saveSets();
        } catch (Exception e) {
    System.out.println("Error reading from file: " + e);
        }
        }

    private void load(){
        try{
            legoSetAPI.loadSets();
        } catch (Exception e) {
            System.out.println("Error reading from file: " + e);
        }
    }
}

    private void ViewLegoSetsMenu() {

    }
}



