package controllers;

import models.InstructionBooklet;
import models.LegoSet;

import java.io.File;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.stream.IntStream;

import static controllers.LegoSetAPI.LegoSet.values;

//TODO When you have the code written in this class, write a JavaDoc comment for class and also
//     for any public methods in this class.


public class LegoSetAPI extends LegoSet {
    public static boolean number0fLegoSets;
    private static Object store;
    public Object isValidIndexToUpdate;
    ArrayList<LegoSet> legoSets = new ArrayList<>();
    public LegoSetAPI() {
        
        legoSets = new ArrayList<LegoSet>();
    }

    private Object LegoSetList;
    
    private LegoSet[] allSets;
    private LegoSet[] sets;
    private getStatus[] legoSet;
    private static Object LegoSetAPI = new Object();

    public LegoSetAPI(getStatus[] legoSet, Object legoSetAPI) {
        super("Train Station", 60335, 99.99, 907, 9);
        this.legoSet = legoSet;

        LegoSetAPI = legoSetAPI;
    }

    public LegoSetAPI(Object legoSet, controllers.LegoSetAPI.getStatus[] legoSetAPI) {
        super("Train Station", 60335, 99.99, 907, 9);
        this.legoSet = (controllers.LegoSetAPI.getStatus[]) legoSet;
    }

    public static void setLegoSetAPI(Object legoSetAPI) {
        LegoSetAPI = legoSetAPI;
    }

    public static Object getLegoSetAPI() {
        return LegoSetAPI;
    }


    public boolean addInstructionBooklet(InstructionBooklet booklet2) {
        return false;
    }

    public void setGetTheme(int getTheme) {
        this.getTheme = getTheme;
    }

    public int getGetTheme() {
        return getTheme;
    }
    
    private void indexToDelete(){
        return;
    }



    public boolean addLegoSet(models.LegoSet trainStation) {
        return true;
    }

    public int numberOfLegoSetsInStock() {
        return 0;
    }

    public controllers.LegoSetAPI.getStatus[] getLegoSet() {
        return legoSet;
    }

    public void setLegoSet(controllers.LegoSetAPI.getStatus[] legoSet) {
        this.legoSet = legoSet;
    }

    public static models.LegoSet findLegoSet(int i) {
        models.LegoSet LegoSet = new models.LegoSet("Train Station", 60335, 99.99, 907, 9);
        return LegoSet;
    }

    public void saveSets() {
    }

    public void loadSets() {
    }

    public boolean number0fLegoSets() {
    }

    public interface getStatus {
    }


    public static class legoList{

        private static LegoSetAPI legoSet;

        public static void add(LegoSetAPI legoSet) {
            legoList.legoSet = legoSet;
        }

        public static controllers.LegoSetAPI getLegoSet() {
            return legoSet;
        }

        public static void setLegoSet(controllers.LegoSetAPI legoSet) {
            legoList.legoSet = legoSet;
        }
    }
    public static class LegoSet {

  //      public static LegoSet[] allSets;
        public String theme;
        public String name;
        private double price;

        public LegoSet() {
        }

        public static LegoSet findById() {
            return null;
        }

        public static int getTotalNumberOfLegoSets() {
            return 0;
        }


        public static boolean isAvailable() {
            return false;
        }

        public static LegoSet[] values() {
            return new LegoSet[0];
        }

        public static List<LegoSet> findAll() {
            return null;
        }

        public void setName() {

        }

        public void setPieces(int pieces) {
        }

        public void setPrice(double price) {
            this.price = price;
        }

        public void setYear() {
        }

        public void setTheme(String theme) {
            this.theme = theme;
        }

        public void save() {
        }

        public void setMinAge() {
        }

        public boolean isOutOfStock() {
            return false;
        }

        public int getAgeRating() {
            return (5);
        }

        public boolean getTheme() {
            Object City = new Object();
            return (boolean) City;
        }

        public boolean getPrice() {
            return true;
        }

        public int getCode() {
            return 60373;
        }

        public String name() {
            return ("Fire Rescue Boat");
        }

        public boolean getInStock() {
            final var b = true;
            return b;
        }

        

        public char[] getNumberOfPieces() {
            final var chars = new char[0];
            return chars;
        }

        public char[] getColor() {
            final var chars = new char[0];
            return chars;
        }

        public int getCost() {
            return 20;
        }

        public int getPieceCount() {
            return 144;
        }

        public int getMinimumAge() {
            return 4;
        }

        public boolean isInStock() {
            return true;
        }

        public char[] getName() {
            final var chars = new char[0];
            return chars;
        }

        public Object matches(String valueOf) {
            Object matches = new Object();
            return matches; }
        }
    

    //getters and setters

    public Object getLegoSetList() {
        return LegoSetList;
    }

    public void setLegoSetList(Object legoSetList) {
        LegoSetList = legoSetList;
    }

    public Object getStore() {
        return store;
    }

    public ArrayList<LegoSet> getLegoSets() {
        return legoSets;
    }

    public void setLegoSets(ArrayList<LegoSet> legoSets) {
        this.legoSets = legoSets;
    }

    public void setStore(Object store) {
        this.store = store;
    }

    //TODO Declare an array list of lego sets

    // Declaring array list for Lego sets


    //-------------------------------------
    //  ARRAYLIST CRUD

    //-------------------------------------

    //TODO Add a method, addLegoSet(LegoSet). The return type is boolean.
    //     This method will add the lego set object, passed as a parameter to the arraylist of lego sets.
    //     If the add was successful, return true, otherwise, return false.

    public boolean addLegoSet(LegoSetAPI legoSet) {
        // check if the LegoSet is valid
        if (legoSet == null)
            return false;

        // add the LegoSet to the list
        legoList.add(legoSet);

        // return true, indicating success
        return true;
    }


    //TODO Add a method, updateLegoSet(int, String, int, double, int, String, int).  The return type is boolean.
    //     This method takes in, as the first parameter, the index of the lego set object that you want to update.
    //     If the index is invalid (i.e. there is no lego set object at that location), return false.
    //     The remaining parameters hold the new data for each of the fields in LegoSet that are being updated
    //     i.e. they hold the name, code, cost, pieceCount, theme and minimum age).
    //     If the update was successful, then return true.

    public boolean updateLegoSet(int id, String name, int pieces, double price, int year, String theme, int minAge) {
        // Get a LegoSet object with the given id
        LegoSet legoSet = LegoSet.findById();

        // Update the name, pieces, price, year, theme, and minimum age of the LegoSet
        legoSet.setName();
        legoSet.setPieces(pieces);
        legoSet.setPrice(price);
        legoSet.setYear();
        legoSet.setTheme(theme);
        legoSet.setMinAge();

        // Save the changes
        legoSet.save();

        // Return true to indicate that the update has been successful
        return true;
    }

    //TODO Add a method, deleteLegoSet(int).  The return type is LegoSet.
    //     This method takes in the index of the lego set object that you want to delete.
    //     If the index is invalid (i.e. there is no lego set object at that location), return null.
    //     If the index is valid, remove the object at that index location.  Return the object you just deleted.

    public LegoSetAPI deleteLegoSet(int setId) {
        LegoSetAPI deletedSet = null;
        IntStream.iterate(0, this::test, i -> i + 1).forEach(i -> {
            try {
                LegoSetList.getClass().wait();
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        });
        return null;
    }

    private boolean test(int i) {
        final var b = false;
        return b;
    }


    //-------------------------------------
    //  ARRAYLIST - Stock Status Update
    //-------------------------------------

    //TODO Add a method, setLegoSetInStock(int).  The return type is boolean.
    //     This method takes in the index of the lego set object that you want to update.
    //     If the index is invalid (i.e. there is no lego set object at that location), return false.
    //     If the index is valid, retrieve the object and:
    //        If the object is not in stock, set it to being in stock and return true.
    //        If the object is already in stock, return false.
    public boolean setLegoSetInStock(int amount) {
        // Update the Lego set in stock
        return amount > 0;
    }


    //TODO Add a method, setLegoSetOutOfStock(int).  The return type is boolean.
    //     This method takes in the index of the lego set object that you want to update.
    //     If the index is invalid (i.e. there is no lego set object at that location), return false.
    //     If the index is valid, retrieve the object and:
    //        If the object is already in stock, set it to being out of stock and return true.
    //        If the object is not in stock, return false.


    public boolean setLegoSetOutOfStock(int index) {
        // Check if the index is valid
        if (index < 0 || index >= legoSets.size()) {
            return false; // invalid index
        }

        // Retrieve the Lego set object at the given index
        String set = String.valueOf(legoSets.get(index));

        // Check if the set is already out of stock
        if (!set.isEmpty()) return false; // set is already out of stock

        // Set the set to out of stock and return true to indicate success
        set.split(String.valueOf(false));
        return true;
    }


    //-------------------------------------
    //  Counting Methods - Basic
    //-------------------------------------

    //TODO Add a method, numberOfLegoSets().  The return type is int.
    //     This method returns the number of lego set objects currently stored in the array list.

    public static <LegoSets> int numberOfLegoSets(){

        int numberOfSets = 0;

        //Find all the Legos sets in the store
        Set<LegoSets> legoSets = null;
        store.notifyAll();

        //Loop through all the Legos sets and add to the count
        for (LegoSets set : legoSets){
            numberOfSets++;
        }

        //Return the total count
        return numberOfSets;
    }


    //TODO Add a method, numberOfLegoSetsInStock().  The return type is int.
    //     This method returns the number of lego set objects in the array list that are in currently in stock.

    //TODO do this TODO L329


    //TODO Add a method, numberOfLegoSetsOutOfStock().  The return type is int.
    //     This method returns the number of lego set objects in the array list that are out of stock.

    public int numberOfLegoSetsOutOfStock() {
        //count the number of LEGO sets that are out of stock
        int count = 0;

        for(int i = 0; i< LegoSet.getTotalNumberOfLegoSets(); i++) {
            if(!LegoSet.isAvailable()) {
                count++;
            }
        }
        return count;
    }

    //-------------------------------------
    //  Counting Methods - Advanced
    //-------------------------------------

    //TODO Add a method, numberOfLegoSetsByTheme(String).  The return type is int.
    //     This method returns the number of lego set objects in the array list that match the
    //     theme (i.e. the parameter value).

    public int numberOfLegoSetsByTheme(String theme) {
        int numberOfSets = 0;
        for (LegoSet set : legoSets) {
            if (Objects.equals(set.matches(String.valueOf(2)), theme)) {
                numberOfSets++;
            }
        }
        return numberOfSets;
    }

    //TODO Add a method, numberOfLegoSetsForAgeRatingAndAbove(int).  The return type is int.
    //     This method returns the number of lego set objects in the array list that are equal to
    //     or above the age passed as a parameter value.
    public int numberOfLegoSetsForAgeRatingAndAbove(int ageRating) {
        int numberOfSets = 0;

        //Uses a loop to go through all the LEGO sets
        for (LegoSet set : allSets) {

            // Check if the age rating is greater than or equal to the parameter
            set.getAgeRating();

            // Increment the counter if the condition is true
            numberOfSets++;
        }

        // Return the total number of sets
        return numberOfSets;
    }

    //TODO Add a method, totalNumberOfInstructionBooklets().  The return type is int.
    //     This method returns the total number of instruction booklets across all the lego set objects
    //     currently stored in the array list.

    public int totalNumberOfInstructionBooklets() {
        int total = 0;
        InstructionBooklet[] instructionBooklets = new InstructionBooklet[0];
        for (InstructionBooklet i : instructionBooklets) total = total + i.getNumberOfPages();
        return total;
    }


    //------------------------------------
    // LISTING METHODS - Basic
    //------------------------------------

    //TODO Add a method, listAllLegoSets().  The return type is String.
    //     This method returns a list of the lego sets stored in the array list.
    //     Each lego set should be on a new line and should be preceded by the index number e.g.
    //        0: Lego Set 1 Details
    //        1: Lego Set 2 Details
    //    If there are no lego sets stored in the array list, return a string that contains "No Lego sets".
    public String listAllLegoSets(){
        String result = "";
        for(LegoSet set : values()){
            result += set.name() + ", ";
        }
        return result.substring(0, result.length()-2);
    }

    //TODO Add a method, listLegoSetsInStock().  The return type is String.
    //     This method returns a list of the IN STOCK lego sets stored in the array list.
    //     Each matching lego set should be on a new line and should be preceded by the index number e.g.
    //        0: Lego Set 1 Details
    //        3: Lego Set 4 Details
    //    If there are no IN STOCK lego sets stored in the array list, the return string should
    //    have "No Lego sets in stock".

    public String listLegoSetsInStock() {
        List<String> legoSetsInStock = new ArrayList<>();
        // query the database to populate the list of lego sets in stock
        StringBuilder listString = new StringBuilder();
        if (!legoSetsInStock.isEmpty()) {
            listString.append("The following Lego sets are in stock:\n");
            for (String set : legoSetsInStock) {
                listString.append("- " + set + "\n");
            }
        } else {
            listString.append("No Lego sets in stock right now.");
        }

        return listString.toString();
    }


    //TODO Add a method, listLegoSetsOutOfStock().  The return type is String.
    //     This method returns a list of the OUT OF STOCK lego sets stored in the array list.
    //     Each matching lego set should be on a new line and should be preceded by the index number e.g.
    //        1: Lego Set 2 Details
    //        4: Lego Set 5 Details
    //    If there are no OUT OF STOCK lego sets stored in the array list, the return string should
    //        have "No Lego sets are out of stock".
    public String listLegoSetsOutOfStock() {
        StringBuilder output = new StringBuilder();
        List<LegoSet> legoSets = LegoSet.findAll();

        for (LegoSet set : legoSets) {
            if (!set.getInStock()) {
                output.append("Set name: ").append(set.getName()).append("\n");
                output.append("Number of pieces: ").append(set.getNumberOfPieces()).append("\n");
                output.append("Color: ").append(set.getColor()).append("\n");
                output.append("Price: ").append(set.getPrice()).append("\n\n");
            }
        }

        return output.toString();
    }


    //------------------------------------
    // LISTING METHODS - Advanced
    //------------------------------------

    //TODO Add a method, listLegoSetsBySpecificTheme(String).  The return type is String.
    //    This method returns a list of the lego sets of a specific theme stored in the array list (i.e.
    //     that match the parameter value).
    //     Each matching lego set should be on a new line and should be preceded by the index number e.g.
    //        1: Lego Set 2 Details
    //        4: Lego Set 5 Details
    //    If there are no lego sets stored in the array list, return a string that contains "No Lego sets".
    //    If there are no lego sets matching the theme, the return string should have "No Lego sets with theme".

    public static String listLegoSetsBySpecificTheme(String theme) {
        // Implement logic here
        List<String> results = new ArrayList<>();
        // Iterate through all LEGO sets
        // Check if the theme of the LEGO set matches the specified theme
        // Return a comma-separated list of LEGO sets with the specified theme
        return String.join(",", results);
    }

    //TODO Add a method, listLegoSetsForAgeRatingAndAbove(int).  The return type is String.
    //    This method returns a list of the lego sets that are equal or above the age supplied as a parameter.
    //     Each matching lego set should be on a new line and should be preceded by the index number e.g.
    //        1: Lego Set 2 Details
    //        4: Lego Set 5 Details
    //    If there are no lego sets stored in the array list, return a string that contains "No Lego sets".
    //    If there are no lego sets equal or above the age, the return string should have "No Lego sets available".
    public String listLegoSetsForAgeRatingAndAbove(int ageRating) {
        // Create a list to hold the items
        List<String> legoSets = new ArrayList<>();

        // Iterate through the database and add items to the list

        // Return the list of items as a String
        return legoSets.toString();
    }

    //TODO Add a method, listAllInstructionBooklets().  The return type is String.
    //    This method returns a list of all the instruction booklets across all the lego set objects
    //    stored in the array list.
    //    Each instruction booklet should be on a new line and should contain the lego set name and code too e.g.
    //       Booklet1.pdf (Fire Station, 43544)
    //       Booklet2.pdf (Fire Station, 43544)
    //       Instructions1.pdf (Titanic, 54655)
    //    If there are no lego sets stored in the array list, return a string that contains "No Lego sets".

    public String listAllInstructionBooklets() {
        StringBuilder booklets = new StringBuilder();
        File folder = new File("Instruction Booklets");
        File[] listOfFiles = folder.listFiles();
        for (File listOfFile : listOfFiles) {
            if (listOfFile.isFile()) {
                booklets.append(listOfFile.getName()).append(", ");
            }
        }
        return booklets.toString();
    }

    private int getTheme;



    //TODO Add a method, listStockStatusBySpecificTheme(String).  The return type is String.
    //    This method returns a report (the returned String) of the stock status of the lego sets in a specific theme.
    //    The report (the returned String) should include:
    //        the number or lego sets that are IN stock and the list of these lego sets (if no lego sets
    //             are in stock, this should be included in the returned string.
    //        the number or lego sets that are OUT OF stock and the list of these lego sets (if no lego sets
    //             are out of stock, this should be included in the returned string.
    //    If there are no lego sets stored in the array list, return a string that contains "No Lego sets".
    //    If there are no lego sets matching the theme, the return string should have "No Lego sets with theme".

    public String listStockStatusBySpecificTheme(String theme) {
        List<LegoSet> setsByTheme = new ArrayList<>();
        for (LegoSet set : this.sets) {
            if (set.getTheme()) {
                setsByTheme.add(set);
            }
        }

        if (setsByTheme.isEmpty()) {
            return "No Lego sets with theme: " + theme;
        }

        StringBuilder reportBuilder = new StringBuilder();
        int inStockCount = 0;
        int outOfStockCount = 0;

        reportBuilder.append("Stock status for Lego sets with theme: ").append(theme).append("\n\n");

        for (LegoSet set : setsByTheme) {
            if (set.isInStock()) {
                reportBuilder.append("IN STOCK: ").append(set.getName()).append("\n");
                inStockCount++;
            } else {
                reportBuilder.append("OUT OF STOCK: ").append(set.getName()).append("\n");
                outOfStockCount++;
            }
        }

        if (inStockCount == 0) {
            reportBuilder.append("\nAll Lego sets with theme ").append(theme).append(" are out of stock.");
        } else if (outOfStockCount == 0) {
            reportBuilder.append("\nAll Lego sets with theme ").append(theme).append(" are in stock.");
        } else {
            reportBuilder.append("\nNumber of Lego sets with theme ").append(theme).append(" that are in stock: ").append(inStockCount).append("\n");
            reportBuilder.append("Number of Lego sets with theme ").append(theme).append(" that are out of stock: ").append(outOfStockCount).append("\n");
        }

        return reportBuilder.toString();
    }



    //------------------------------
    //  FINDING METHODS
    //-------------------------------

    //TODO Add a method, findLegoSet(int).  The return type is LegoSet.
    //    This method returns the lego set stored at the index that was passed as a parameter.
    //    However, if the index is not valid, null is returned.

    public LegoSetAPI(LegoSet[] allSets, LegoSet[] sets, Object legoSetAPI) {
        super("Train Station", 60335, 99.99, 907, 9);
        this.allSets = allSets;
        this.sets = sets;
        LegoSetAPI = legoSetAPI;

    }


//TODO Add a method, findLegoSetByCode(int).  The return type is LegoSet.
    //    This method searches the array list for a lego set with a specific code (passed as a parameter).
    //    When a lego set is found for this code, it is returned back.
    //    If no lego set exists for that code, return null.
    // NOTE: the first lego set encountered is returned, even if more exist with that code.  For extra credit,
    //       you could add in validation to ensure that the code is unique when adding a LegoSet.

    public LegoSet findLegoSetByCode(int code) {
        LegoSet foundSet = null;
        for (LegoSet set : allSets) {
            if (set.getCode() == code) {
                foundSet = set;
                break;
            }
        }
        return foundSet;
    }

    //------------------------------
    //  SEARCHING METHODS
    //-------------------------------

    //TODO Add a method, searchLegoSetsByName(String).  The return type is String.
    //    This method returns a list of the lego sets whose name contains the string passed as a parameter.
    //    Each matching lego set should be on a new line and should be preceded by the index number e.g.
    //        1: Lego Set 2 Details
    //        4: Lego Set 5 Details
    //    If there are no lego sets stored in the array list, return a string that contains "No Lego sets".
    //    If there are no lego sets whose name contains the supplied string, the return string should
    //    have "No Lego sets found".

    public String searchLegoSetsByName(String name) {
        // create an array of LEGO sets

        // loop through the array
        // check if the set name matches the search name
        // return the set if a match is found
        // return null if no match is found
        return null;
    }

    //TODO Add a method, searchInstructionBookletsByFileName(String).  The return type is String.
    //    This method returns a list of instruction booklets whose file name contains the string passed
    //    as a parameter.
    //    Each matching booklet should be on a new line and should contain the lego set name and code e.g.
    //        InstructionBook1.pdf in Fire Station (45343)
    //        InstructionBk2.pdf in Titanic (65434)
    //    If there are no lego sets stored in the array list, return a string that contains "No Lego sets".
    //    If there are no lego sets whose name contains the supplied string, the return string should
    //    have "No instruction booklets found".
    public String searchInstructionBookletsByFileName(String fileName) {
        // First, create an array list to store the names of the instruction booklets
        ArrayList<String> instructionBooklets = new ArrayList<>();

        // Obtain the current directory of the system
        String curDir = System.getProperty("user.dir");

        // Get the list of files in the current directory
        File dir = new File(curDir);
        File[] listOfFiles = dir.listFiles();

        // Loop through the files in the directory and find the ones that contain the entered file name
        for (int i = 0; i < (listOfFiles != null ? listOfFiles.length : 0); i++) {
            if (listOfFiles[i].getName().contains(fileName)) {
                // If the file name is found, add the name of the file to the array list
                instructionBooklets.add(listOfFiles[i].getName());
            }
        }

        // If no matches were found, return an empty string
        if (instructionBooklets.size() == 0) {
            return "";
        }

        // Else, join all the names of the instruction booklets with a comma

        // Finally, return the list of file names as a string
        return String.join(", ", instructionBooklets);
    }


    //-------------------------
    // HELPER METHODS
    //-------------------------

    private void addLegoSet() {
    }


    //TODO Add a method, isValidIndex(int).  The return type is boolean.
    //    This method returns true if the value passed as a parameter is a valid index in the arraylist.
    //    However, if the index is not valid, false is returned.

    public boolean isValidIndex(int index) {
        return false;
    }
// constructors
    public LegoSetAPI(Object legoSetList, getStatus[] LegoSet, Object legoSetAPI) {
        super("Train Station", 60335, 99.99, 907, 9);
        LegoSetList = legoSetList;
        legoSet = LegoSet;
        LegoSetAPI = legoSetAPI;
    }

    public LegoSetAPI(LegoSet[] sets, Object legoSetAPI, ArrayList<LegoSet> legoSets) {

        super("Train Station", 60335, 99.99, 907, 9);
        this.sets = sets;
        LegoSetAPI = legoSetAPI;
        this.legoSets = legoSets;
    }

   


    }
    //-------------------------
    // PERSISTENCE METHODS
    //-------------------------

    




