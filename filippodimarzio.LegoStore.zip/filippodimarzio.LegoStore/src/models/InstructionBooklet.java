package models;

import java.util.Objects;

public class InstructionBooklet {

    private int numberOfPages = 1;
    private String fileName;

    public InstructionBooklet(int numberOfPages, String fileName) {
       setNumberOfPages(numberOfPages);
        this.fileName = fileName;
    }

    public InstructionBooklet(int numberOfPages, String fileName, Object instructionBooklet) {
        this.numberOfPages = numberOfPages;
        this.fileName = fileName;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public int getNumberOfPages() {
        return numberOfPages;
    }

    public void setNumberOfPages(int numberOfPages) {
        if (numberOfPages > 0 && numberOfPages <= 80) {
          this.numberOfPages = numberOfPages;
            }
    }

//TODO The number of pages (int) is between 1 and 80 (both inclusive).  Default is 1.




    //TODO The file name (String) of the booklet in the system is entered by the user.
    //     Default value is "".
    //     When creating the booklet, truncate the name to 20 characters.
    //     When updating an existing booklet, only update the name if it is 20 characters or fewer.

    public String setBookletName(String name) {
        String fileName = name;
        // If a name is passed as an argument
        if (name.length() > 0) {
            // Truncate the name to 20 characters
            if (name.length() > 20) {
                int index = 20;
                fileName = name.substring(0, index);
            }
        } else {
            fileName = "";
        }
        return fileName;
    }



    //TODO Add the constructor, InstructionBooklet(int, String), that adheres to the above validation rules


    //TODO Add a getter and setter for each field, that adheres to the above validation rules



    //TODO Add a generated equals method.

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        InstructionBooklet that = (InstructionBooklet) o;
        return numberOfPages == that.numberOfPages && Objects.equals(fileName, that.fileName);
    }

    @Override
    public int hashCode() {
        return Objects.hash(numberOfPages, fileName);
    }


    //TODO The toString should return the string in this format:
        //      legoBooklet1.pdf (5 pages)  OR
        //      legoBooklet2.pdf (1 page)   OR
        //      legoBooklet3.pdf (0 pages)
        //  NOTE: .pdf is added to the actual file name if the user hasn't added it themselves.
        //  NOTE: "pages" is added to the number of pages when it is not equal 1, "page" otherwise.

        public  String toString(){
            String output = "";
            int numPages = 0;
            String legoBooklet1 = new String();
            if (numPages == 1) {
                output += legoBooklet1 + ".pdf (" + numPages + " page)";
            } else {
                output += legoBooklet1 + ".pdf (" + numPages + " pages)";
            }
            return (output);
        }

    }
