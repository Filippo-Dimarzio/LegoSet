package models;
import java.util.ArrayList;
import java.util.Collection;


public class LegoSet {

    private int minAge;
    private double cost;


    int pieceCount = 1;


    private ArrayList<InstructionBooklet> instructionBooklets = new ArrayList<>();

    public LegoSet() {

    }

    public LegoSet(String legoSetName, int legoSetCode, double legoSetCost, int legoSetPiece, String theme, int age) {


    }

    public int getMinAge() {
        return this.minAge;
    }


    // TODO The lego set name field (String) has a maximum 35 chars.
    //     Default value is "".
    //     When creating the lego set, truncate the name to 35 characters.
    //     When updating an existing lego set, only update the name if it is 35 characters or fewer.


    private static final int MAX_CHARS = 35;



        public LegoSet(String train_station, int i, double v, int i1, int i2) {
            
        }

        public void setName(String name) {
            String name1 = "";
            if (name.length() > MAX_CHARS) {
                name1 = name.substring(0, MAX_CHARS);
            } else {
                name1 = name;

            }
        }

        //TODO The piece count field (int) must be between 1 and 2000 (both inclusive). The default value is 1.



        public void setPieceCount(int pieceCount) {
            if (pieceCount < 1 || pieceCount > 2000) {
                throw new IllegalArgumentException("Piece count must be between 1 and 2000");

            }

        }
    public int getPieceCount() {
            return this.pieceCount;
    }

        // TODO The code field (int) must be between 10000 and 99999 (both inclusive).  Default value is 10000.
private int myField = 10000; // Default value

        public void setMyField(int value) {
         if (value >= 10000 && value <= 99999) {
        }    else {
             throw new IllegalArgumentException("myField value must be between 10000 and 99999") ;
         }
    }

    public int getMyField() {
        return myField;
        }

        public boolean addInstructionBooklet(InstructionBooklet booklet1) {

            return false;
        }

        public void setInStock(boolean b) {

        }

        public int getCode() {
            return 60373;
        }

    public int getMinimumAge() {
            return 5;
        }

        public boolean isInStock() {
          return true;
        }

        public String getName() {
        return ("Fire Rescue Boat");
        }

        public int setCode(int i) {
          return 9999;
        }

        public int setCost(int i) {
            return 30;
        }

        public int numberOfInstructionBooklets() {
            return 2;
        }

    public void setCost(double cost) {
        this.cost = cost;
    }

    public void setTheme() {
        }

        public void setMinimumAge(int i) {
        }

        public int findInstructionBooklet(int i) {
            return i;
        }

        public boolean updateInstructionBooklet(int i, String newFileName, int i1) {
            return false;
        }

        public Object deleteInstructionBooklet(int i) {
            return false;
        }

        public boolean isValidIndex(int i) {
            return false;
        }

        public Collection<Object> listInstructionBooklets() {
            return null;
        }



        //TODO The cost field (double) must be greater than zero.  The default value is MAX_VALUE for Double.

    public void SetCost(double cost){
        if (cost <= 0) {
            throw new IllegalArgumentException("Cost must be greater than zero");
        }
        this.cost = cost;
    }
     public double getCost(){
        return cost;
    }



//TODO The in stock field (boolean) has a default of true i.e. it is in stock.

//TODO The theme field (String) has valid values of Classic, City, Creator, or Friends.
    //     The default value is "Classic";

    private String theme;

    public static final String[] VALID_THEMES = {"Classic", "City", "Creator", "Friends"};

    public String getTheme() {
        return this.theme;
    }

    private boolean isValidTheme(String theme) {
        for (String validTheme : VALID_THEMES) {
            if (validTheme.equalsIgnoreCase(theme)) {
                return true;
            }
        }
        return false;
    }


    public ArrayList<InstructionBooklet> getInstructionBooklets() {
        return instructionBooklets;
    }

    public void setInstructionBooklets(ArrayList<InstructionBooklet> instructionBooklets) {
        this.instructionBooklets = instructionBooklets;
    }

    public void setTheme(String architecture) {
    }

    public void setMinAge(int minAge) {
        this.minAge = minAge;
    }

    public void addInstructionBook(InstructionBooklet instructionBooklet) {
    }
}


